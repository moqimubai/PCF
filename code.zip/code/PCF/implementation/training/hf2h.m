function xf = hf2h(Xf, pad)
    X=cifft2(full_fourier_coeff(Xf));
    x= X(1+pad(1):end-pad(1),1+pad(2):end-pad(2), :);
    Xz=zeros(size(X));
    Xz(1+pad(1):end-pad(1),1+pad(2):end-pad(2), :)=x;
    xf = compact_fourier_coeff(cfft2(Xz));
end